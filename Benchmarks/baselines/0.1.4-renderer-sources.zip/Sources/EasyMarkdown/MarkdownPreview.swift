import SwiftUI
import WebKit
import UniformTypeIdentifiers
import CryptoKit

private final class WeakReaderMessageHandler: NSObject, WKScriptMessageHandler {
    weak var target: (any WKScriptMessageHandler)?
    init(_ target: any WKScriptMessageHandler) { self.target = target }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(userContentController, didReceive: message)
    }
}

final class LocalResourceHandler: NSObject, WKURLSchemeHandler {
    var root: URL?
    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url, let root else {
            urlSchemeTask.didFailWithError(URLError(.fileDoesNotExist)); return
        }
        let file = URL(fileURLWithPath: url.path).standardizedFileURL.resolvingSymlinksInPath()
        let folder = root.standardizedFileURL.resolvingSymlinksInPath().path + "/"
        guard file.path.hasPrefix(folder), let type = UTType(filenameExtension: file.pathExtension),
              type.conforms(to: .image) else {
            urlSchemeTask.didFailWithError(URLError(.noPermissionsToReadFile)); return
        }
        do {
            let data = try Data(contentsOf: file)
            urlSchemeTask.didReceive(URLResponse(url: url, mimeType: type.preferredMIMEType ?? "application/octet-stream",
                                               expectedContentLength: data.count, textEncodingName: nil))
            urlSchemeTask.didReceive(data); urlSchemeTask.didFinish()
        } catch { urlSchemeTask.didFailWithError(error) }
    }
    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}
}

struct MarkdownPreview: NSViewRepresentable {
    let session: DocumentSession
    var overrideText: String? = nil
    @AppStorage("readerFontSize") private var fontSize = 16.0
    @AppStorage("readerWidth") private var width = 780.0
    @AppStorage("remoteImages") private var remoteImages = false
    @AppStorage("appearance") private var appearance = "system"

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeNSView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        configuration.userContentController.add(WeakReaderMessageHandler(context.coordinator), name: "reader")
        configuration.setURLSchemeHandler(context.coordinator.resources, forURLScheme: "document-resource")
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.setValue(false, forKey: "drawsBackground")
        context.coordinator.webView = webView
        if overrideText == nil {
            session.scrollPreviewTo = { [weak coordinator = context.coordinator] position in
                coordinator?.synchronizeScroll(position)
            }
        }
        if let page = AppResources.bundle.url(forResource: "reader", withExtension: "html", subdirectory: "Resources") {
            webView.loadFileURL(page, allowingReadAccessTo: page.deletingLastPathComponent())
        }
        return webView
    }

    func updateNSView(_ webView: WKWebView, context: Context) {
        context.coordinator.parent = self
        context.coordinator.update()
    }

    static func dismantleNSView(_ webView: WKWebView, coordinator: Coordinator) {
        coordinator.isDisposed = true
        coordinator.renderTask?.cancel()
        coordinator.renderTask = nil
        coordinator.ready = false
        coordinator.previousText = nil
        coordinator.pendingScroll = nil
        webView.stopLoading()
        webView.navigationDelegate = nil
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "reader")
        coordinator.webView = nil
    }

    @MainActor final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        var parent: MarkdownPreview
        weak var webView: WKWebView?
        let resources = LocalResourceHandler()
        var ready = false
        var previousText: String?
        var previousPreferences = ""
        var previousTarget: String?
        var previousScrollRequest = 0
        var previousSearch = ""
        var previousFindRequest = 0
        var rendering = false
        var pendingScroll: SplitScrollPosition?
        var hasAlignedScroll = false
        var scrolling = false
        var renderTask: Task<Void, Never>?
        var isDisposed = false

        func synchronizeScroll(_ position: SplitScrollPosition) {
            pendingScroll = position
            flushScroll()
        }

        private func flushScroll() {
            guard ready, !rendering, !scrolling, let webView, let position = pendingScroll,
                  parent.overrideText == nil, parent.session.mode == .split,
                  parent.session.synchronizeSplitScroll else { return }
            pendingScroll = nil
            scrolling = true
            webView.callAsyncJavaScript("window.synchronizeSourceScroll(position)",
                arguments: ["position": position.arguments], in: nil, in: .page) { [weak self] _ in
                    self?.scrolling = false
                    self?.flushScroll()
                }
        }

        init(_ parent: MarkdownPreview) { self.parent = parent }
        var positionKey: String {
            let hash = SHA256.hash(data: Data((parent.session.url?.path ?? "").utf8))
                .map { String(format: "%02x", $0) }.joined()
            return "readingPosition." + hash
        }

        func update() {
            guard ready, !isDisposed, let webView else { return }
            if !hasAlignedScroll && previousText != nil && !rendering,
               parent.overrideText == nil && parent.session.mode == .split {
                hasAlignedScroll = true
                Task { @MainActor [weak self] in
                    try? await Task.sleep(for: .milliseconds(100))
                    guard let self, !self.isDisposed else { return }
                    self.parent.session.alignPreviewToEditor?()
                }
            }
            resources.root = parent.session.url?.deletingLastPathComponent()
            let text = parent.overrideText ?? parent.session.state.text
            let preferences: [String: Any] = ["fontSize": parent.fontSize, "width": parent.width,
                "appearance": parent.appearance, "remoteImages": parent.remoteImages]
            let preferencesKey = "\(parent.fontSize):\(parent.width):\(parent.appearance):\(parent.remoteImages)"
            if !rendering && (previousText != text || previousPreferences != preferencesKey) {
                renderTask?.cancel()
                // Coalesce typing bursts before creating IPC arguments and a new DOM tree.
                renderTask = Task { @MainActor [weak self] in
                    if self?.previousText != nil {
                        try? await Task.sleep(for: .milliseconds(100))
                    }
                    guard !Task.isCancelled, let self, !self.isDisposed else { return }
                    self.render(text: text, preferences: preferences, preferencesKey: preferencesKey)
                }
            }
            if previousSearch != parent.session.search || previousFindRequest != parent.session.findRequest {
                previousSearch = parent.session.search
                previousFindRequest = parent.session.findRequest
                webView.find(previousSearch, configuration: WKFindConfiguration()) { _ in }
            }
            if let target = parent.session.scrollTarget,
               target != previousTarget || parent.session.scrollRequest != previousScrollRequest {
                previousTarget = target
                previousScrollRequest = parent.session.scrollRequest
                webView.callAsyncJavaScript("document.getElementById(target)?.scrollIntoView()",
                    arguments: ["target": target], in: nil, in: .page, completionHandler: nil)
            }
        }

        private func render(text: String, preferences: [String: Any], preferencesKey: String) {
            guard let webView, ready, !rendering else { return }
            previousText = text; previousPreferences = preferencesKey; rendering = true
            let position = UserDefaults.standard.dictionary(forKey: positionKey) ?? [:]
            // The reader already truncates at 500k characters; don't transfer 24 MB to
            // WebKit merely to discard it there. Keep one extra character for the notice.
            let previewText = text.utf16.count > 500_001 ? String(text.prefix(500_001)) : text
            webView.callAsyncJavaScript("window.updateDocument(text, kind, baseURL, preferences, position)",
                arguments: ["text": previewText, "kind": parent.session.kind.rawValue,
                    "baseURL": parent.session.url?.absoluteString ?? "file:///", "preferences": preferences,
                    "position": position], in: nil, in: .page) { [weak self] result in
                guard let self, !self.isDisposed else { return }
                self.rendering = false
                if case .failure(let error) = result { self.parent.session.errorMessage = "预览失败：\(error.localizedDescription)" }
                else {
                    self.update()
                    if !self.hasAlignedScroll && self.parent.overrideText == nil && self.parent.session.mode == .split {
                        self.hasAlignedScroll = true
                        // Wait for the reader's initial position restoration to finish.
                        Task { @MainActor [weak self] in
                            try? await Task.sleep(for: .milliseconds(100))
                            self?.parent.session.alignPreviewToEditor?()
                        }
                    }
                    self.flushScroll()
                }
            }
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.frameInfo.isMainFrame, let body = message.body as? [String: Any],
                  let type = body["type"] as? String else { return }
            switch type {
            case "ready": ready = true; update()
            case "headings":
                guard parent.overrideText == nil, let payload = body["payload"],
                      let data = try? JSONSerialization.data(withJSONObject: payload),
                      let headings = try? JSONDecoder().decode([Heading].self, from: data) else { return }
                parent.session.headings = headings
            case "position":
                if parent.overrideText == nil, let position = body["payload"] as? [String: Any] {
                    UserDefaults.standard.set(position, forKey: positionKey)
                }
            case "sourceScroll":
                guard parent.overrideText == nil, !rendering,
                      previousText == parent.session.state.text,
                      let payload = body["payload"] as? [String: Any],
                      let offset = payload["offset"] as? Double,
                      let progress = payload["progress"] as? Double else { return }
                parent.session.previewDidScroll(SplitScrollPosition(offset: offset, progress: progress))
            case "link":
                if let href = body["payload"] as? String { openLink(href) }
            default: break
            }
        }

        func openLink(_ href: String) {
            guard let url = URL(string: href, relativeTo: parent.session.url)?.absoluteURL,
                  let scheme = url.scheme?.lowercased() else { return }
            if ["https", "http", "mailto"].contains(scheme) { NSWorkspace.shared.open(url) }
            else if url.isFileURL { (NSApp.delegate as? AppDelegate)?.open(url) }
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if navigationAction.navigationType == .linkActivated {
                decisionHandler(.cancel)
                if let url = navigationAction.request.url { openLink(url.absoluteString) }
            } else { decisionHandler(navigationAction.navigationType == .other ? .allow : .cancel) }
        }
    }
}
