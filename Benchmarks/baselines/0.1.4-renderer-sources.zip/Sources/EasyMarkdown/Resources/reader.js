/* All document content is untrusted. Sanitize before insertion; never interpolate it into JS. */
const content = document.getElementById('content');
const send = (type, payload) => window.webkit?.messageHandlers.reader?.postMessage({type, payload});
let lastPosition = null;
let restoring = false;
let imageResizeObserver;
let sourceBlocks = [];
let synchronizedY = null;
let renderGeneration = 0;
let sourceScrollTimer;

function sourcePosition() {
  const maximum = Math.max(0, document.documentElement.scrollHeight - innerHeight);
  const progress = maximum ? Math.min(1, Math.max(0, scrollY / maximum)) : 0;
  if (!sourceBlocks.length) return {offset:0, progress};
  let index = 0;
  for (let i = 0; i < sourceBlocks.length; i++) {
    if (sourceBlocks[i].element.getBoundingClientRect().top <= 0.5) index = i;
    else break;
  }
  const block = sourceBlocks[index];
  const top = block.element.getBoundingClientRect().top + scrollY;
  const bottom = sourceBlocks[index + 1]?.element.getBoundingClientRect().top + scrollY ||
    block.element.getBoundingClientRect().bottom + scrollY;
  const fraction = Math.max(0, Math.min(1, (scrollY - top) / Math.max(1, bottom - top)));
  return {offset:block.start + fraction * (block.end - block.start), progress};
}

window.synchronizeSourceScroll = function(position) {
  if (!sourceBlocks.length) return;
  // A newer synchronized move supersedes a render's pending position restoration.
  restoring = false;
  clearTimeout(sourceScrollTimer);
  sourceScrollTimer = null;
  const maximum = Math.max(0, document.documentElement.scrollHeight - innerHeight);
  let y;
  if (position.progress <= 0.0001) y = 0;
  else if (position.progress >= 0.9999) y = maximum;
  else {
    let index = 0;
    for (let i = 0; i < sourceBlocks.length; i++) {
      if (sourceBlocks[i].start <= position.offset) index = i;
      else break;
    }
    const block = sourceBlocks[index];
    const top = block.element.getBoundingClientRect().top + scrollY;
    const next = sourceBlocks[index + 1];
    const bottom = next ? next.element.getBoundingClientRect().top + scrollY :
      block.element.getBoundingClientRect().bottom + scrollY;
    const fraction = Math.max(0, Math.min(1, (position.offset - block.start) / Math.max(1, block.end - block.start)));
    y = top + fraction * (bottom - top);
  }
  synchronizedY = Math.min(maximum, Math.max(0, y));
  window.scrollTo(0, synchronizedY);
  synchronizedY = scrollY;
  lastPosition = capturePosition();
};

function blocks() { return [...content.children].filter(e => e.textContent.trim()); }
function capturePosition() {
  const items = blocks();
  const anchor = items.find(e => e.getBoundingClientRect().bottom > 18);
  const key = anchor?.textContent.trim().slice(0, 180) || '';
  const duplicate = anchor ? items.filter(e => e.textContent.trim().slice(0, 180) === key).indexOf(anchor) : 0;
  return {key, duplicate, offset:anchor?.getBoundingClientRect().top || 0,
    ratio:scrollY / Math.max(1, document.documentElement.scrollHeight - innerHeight)};
}

function restorePosition(position) {
  if (!position) return;
  const matches = blocks().filter(e => e.textContent.trim().slice(0, 180) === position.key);
  const anchor = matches[position.duplicate || 0];
  const y = anchor ? anchor.getBoundingClientRect().top + scrollY - position.offset :
    position.ratio * Math.max(0, document.documentElement.scrollHeight - innerHeight);
  window.scrollTo(0, Math.max(0, y));
}

window.updateDocument = function(text, kind, baseURL, preferences, savedPosition) {
  const generation = ++renderGeneration;
  const position = content.childElementCount ? capturePosition() : savedPosition;
  restoring = true;
  document.documentElement.style.setProperty('--size', preferences.fontSize + 'px');
  document.documentElement.style.setProperty('--width', preferences.width + 'px');
  document.documentElement.dataset.appearance = preferences.appearance;
  const limit = 500000;
  const truncated = text.length > limit;
  const source = truncated ? text.slice(0, limit) : text;
  let nextContent;
  sourceBlocks = [];
  if (kind === 'markdown' && !truncated) {
    nextContent = document.createDocumentFragment();
    const tokens = marked.lexer(source, {gfm:true, breaks:false});
    // marked normalizes CRLF to LF. Translate its UTF-16 offsets back to the editor's original text.
    const removedCR = [];
    for (const match of source.matchAll(/\r\n/g)) removedCR.push(match.index - removedCR.length + 1);
    const originalOffset = offset => {
      let low = 0, high = removedCR.length;
      while (low < high) {
        const middle = (low + high) >>> 1;
        if (removedCR[middle] <= offset) low = middle + 1;
        else high = middle;
      }
      return offset + low;
    };
    const inertDocument = document.implementation.createHTMLDocument('');
    const staging = inertDocument.createElement('div');
    const template = inertDocument.createElement('template');
    let offset = 0;
    for (const token of tokens) {
      const start = originalOffset(offset);
      offset += token.raw.length;
      const single = [token];
      single.links = tokens.links;
      // Parse into an inert document; nothing can execute or fetch resources here.
      template.innerHTML = marked.parser(single, {gfm:true, breaks:false});
      for (const element of template.content.children) sourceBlocks.push({element, start, end:originalOffset(offset)});
      staging.append(template.content);
    }
    // Sanitize the complete detached tree once, without allocating a parser
    // document and cloned fragment separately for every Markdown block.
    DOMPurify.sanitize(staging, {
      IN_PLACE:true, ALLOW_DATA_ATTR:false,
      FORBID_TAGS:['script','style','iframe','object','embed','form','textarea','button','svg','math','video','audio','link','meta','base'],
      FORBID_ATTR:['style','srcset','autofocus','contenteditable','name']
    });
    sourceBlocks = sourceBlocks.filter(block => block.element.parentNode === staging);
    DOMPurify.removed = [];
    while (staging.firstChild) nextContent.append(staging.firstChild);
  } else {
    nextContent = document.createDocumentFragment();
    const pre = document.createElement('pre');
    pre.className = 'plain';
    const code = document.createElement('code');
    code.textContent = source;
    if ((kind === 'json' || kind === 'xml') && source.length < 150000) code.className = 'language-' + kind;
    pre.append(code); nextContent.append(pre);
    sourceBlocks.push({element:pre, start:0, end:source.length});
  }
  if (truncated) {
    const notice = document.createElement('div'); notice.className = 'notice';
    notice.textContent = '大文件已使用纯文本预览，仅显示前 500,000 个字符。编辑模式可查看和编辑全文。';
    nextContent.prepend(notice);
  }
  nextContent.querySelectorAll('img').forEach(img => {
    const original = img.getAttribute('src') || '';
    try {
      const resolved = new URL(original, baseURL);
      if (resolved.protocol === 'file:') {
        img.src = 'document-resource://local' + resolved.pathname;
      } else if (['https:','http:'].includes(resolved.protocol)) {
        if (!preferences.remoteImages) {
          const placeholder = document.createElement('span'); placeholder.className = 'image-placeholder';
          placeholder.textContent = '[远程图片未加载' + (img.alt ? '：' + img.alt : '') + ']';
          img.replaceWith(placeholder);
        } else { img.referrerPolicy = 'no-referrer'; img.loading = 'lazy'; }
      } else if (!original.startsWith('data:image/')) { img.removeAttribute('src'); }
    } catch { img.removeAttribute('src'); }
  });
  content.replaceChildren(nextContent);
  const ids = new Set();
  const headings = [...content.querySelectorAll('h1,h2,h3,h4,h5,h6')].map(el => {
    const title = el.textContent.trim();
    let slug = title.toLowerCase().replace(/[^\p{L}\p{N}\s_-]/gu,'').replace(/\s+/g,'-') || 'section';
    const base = slug; let n = 1;
    while (ids.has(slug)) slug = base + '-' + n++;
    ids.add(slug); el.id = slug;
    return {id:slug, title, level:Number(el.tagName.slice(1))};
  });
  content.querySelectorAll('input').forEach(e => { e.disabled = true; });
  content.querySelectorAll('a').forEach(e => { e.removeAttribute('target'); e.removeAttribute('download'); });
  if (source.length < 150000) {
    content.querySelectorAll('pre code[class*=language-]').forEach(el => {
      try { hljs.highlightElement(el); } catch { /* Unsupported language remains plain text. */ }
    });
  }
  send('headings', headings);
  // Background WebKit pages may suspend animation frames; restore synchronously too.
  restorePosition(position);
  const finishRestoring = () => {
    if (generation !== renderGeneration || !restoring) return;
    restorePosition(position);
    synchronizedY = scrollY;
    restoring = false; lastPosition = capturePosition();
  };
  requestAnimationFrame(() => {
    if (generation !== renderGeneration || !restoring) return;
    restorePosition(position);
    // WebKit can apply its own scroll compensation after this first layout.
    requestAnimationFrame(() => {
      if (generation !== renderGeneration || !restoring) return;
      restorePosition(position);
      requestAnimationFrame(() => {
        finishRestoring();
      });
    });
  });
  // A background window may suspend animation frames indefinitely.
  setTimeout(finishRestoring, 80);
  // Image loads above the viewport should not shift the current reading anchor.
  imageResizeObserver?.disconnect();
  imageResizeObserver = new ResizeObserver(() => {
    if (!restoring && lastPosition) restorePosition(lastPosition);
  });
  content.querySelectorAll('img').forEach(img => imageResizeObserver.observe(img));
};

let scrollTimer;
addEventListener('scroll', () => {
  if (restoring) return;
  lastPosition = capturePosition();
  clearTimeout(scrollTimer);
  scrollTimer = setTimeout(() => send('position', lastPosition), 200);
  if (synchronizedY !== null && Math.abs(scrollY - synchronizedY) < 1) return;
  synchronizedY = null;
  if (sourceScrollTimer) return;
  sourceScrollTimer = setTimeout(() => {
    sourceScrollTimer = null;
    if (!restoring && (synchronizedY === null || Math.abs(scrollY - synchronizedY) >= 1)) {
      send('sourceScroll', sourcePosition());
    }
  }, 16);
}, {passive:true});

content.addEventListener('click', event => {
  const link = event.target.closest('a');
  if (!link) return;
  event.preventDefault();
  const href = link.getAttribute('href') || '';
  if (href.startsWith('#')) {
    try { document.getElementById(decodeURIComponent(href.slice(1)))?.scrollIntoView(); } catch {}
  } else { send('link', href); }
});
send('ready', true);
